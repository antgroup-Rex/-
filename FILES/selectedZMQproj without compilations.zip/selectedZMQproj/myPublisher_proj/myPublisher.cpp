#include "../include/zmq.h"
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv [])
{
	/*
	ref by 
		http://zguide.zeromq.org/cpp:psenvsub
		http://zguide.zeromq.org/cpp:psenvpub
		http://zguide.zeromq.org/c:espresso
		http://zguide.zeromq.org/py:all#Chapter-Advanced-Pub-Sub-Patterns
		http://zguide.zeromq.org/cpp:wuserver
	*/

    const char *bind_to = "tcp://*:5563";  //"tcp://localhost:5563");
    int roundtrip_count = 10;
    size_t message_size = 200;
	int connection_type = ZMQ_PUB;
	void *ctx;
    void *s;
    int rc;
    int i;
    zmq_msg_t msg;

    ctx = zmq_init (1);
    if (!ctx) {
        printf ("error in zmq_init: %s\n", zmq_strerror (errno));
        return -1;
    }

    s = zmq_socket (ctx, connection_type);
    if (!s) {
        printf ("error in zmq_socket: %s\n", zmq_strerror (errno));
        return -1;
    }

    rc = zmq_bind (s, bind_to);
    if (rc != 0) {
        printf ("error in zmq_bind: %s\n", zmq_strerror (errno));
        return -1;
    }

    rc = zmq_msg_init (&msg);
    if (rc != 0) {
        printf ("error in zmq_msg_init: %s\n", zmq_strerror (errno));
        return -1;
    }

    for (i = 0; i != roundtrip_count; i++) 
	{			
		rc = zmq_msg_init_size(&msg, message_size);
		if  (rc< 0 ) 
			return -1;

		memset (zmq_msg_data (&msg), ' ', message_size);

		char string [100];
		sprintf_s (string, "AAA AAA AbA DDb skjdf sdfjsnf sdfnsdjflkdsdfjnsdfksjf");

		sprintf_s (string, "AAAs ABC AAA %c-%05d", rand ()+12 + 'A', rand ()*100000);
		
		memcpy (zmq_msg_data (&msg), string, sizeof(string));

		printf ("sending zmq_sendmsg: %i\n", i);
		rc = zmq_msg_send(&msg, s, 0);	
        if (rc < 0) {
            printf ("error in zmq_sendmsg: %s\n", zmq_strerror (errno));
            return -1;
        }
		zmq_sleep (1); //[sec]
    }
/*
    rc = zmq_msg_close (&msg);
    if (rc != 0) {
        printf ("error in zmq_msg_close: %s\n", zmq_strerror (errno));
        return -1;
    }

    zmq_sleep (1);
*/
    rc = zmq_close (s);
    if (rc != 0) {
        printf ("error in zmq_close: %s\n", zmq_strerror (errno));
        return -1;
    }

    rc = zmq_ctx_term (ctx);
    if (rc != 0) {
        printf ("error in zmq_ctx_term: %s\n", zmq_strerror (errno));
        return -1;
    }

    return 0;
}
